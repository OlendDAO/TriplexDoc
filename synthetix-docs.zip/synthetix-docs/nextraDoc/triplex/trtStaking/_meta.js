export default {
  index: 'TRT Staking 介绍',
  'staking-guide': '质押指南',
  'rewards': '奖励机制',
  'calculator': '质押计算器',
  'faq': '常见问题',
  'risks': '风险说明'
} 